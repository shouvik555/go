# getlang

Fast natural language detection.

## Supported Languages

| Language       | ISO 639-1 |
| -------------- | --------- |
| Arabic         | ar        |
| Bengali (Bangla) | bn      |
| German         | de        |
| Greek          | el        |
| English        | en        |
| Spanish        | es        |
| French         | fr        |
| Hebrew         | he        |
| Hindi          | hi        |
| Hungarian      | hu        |
| Armenian       | hy        |
| Gujarati       | gu        |
| Italian        | it        |
| Dutch          | nl        |
| Polish         | pl        |
| Portuguese     | pt        |
| Punjabi        | pa        |
| Japanese       | ja        |
| Kannada        | ka        |
| Korean         | ko        |
| Tamil		       | ta        |
| Telugu         | te        |
| Tagalog        | tl        |
| Thai           | th        |
| Russian        | ru        |
| Serbian        | sr        |
| Vietnamese     | vi        |
| Ukrainian      | uk        |
| Chinese        | zh        |
